import argparse, json, math
from pathlib import Path

def triangulate(left,right,focal=800.0,baseline=0.5):
    if focal<=0 or baseline<=0: raise ValueError('Positive calibration required')
    disparity=left[0]-right[0]
    if disparity<=0: raise ValueError('Positive disparity required')
    z=focal*baseline/disparity
    return [left[0]*z/focal,left[1]*z/focal,z]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='output');args=parser.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    truth=[[-.5,-.2,3],[.5,-.2,3],[.5,.2,4],[-.5,.2,4],[0,0,2]]
    points=[]
    for x,y,z in truth: points.append(triangulate([800*x/z,800*y/z],[800*(x-.5)/z,800*y/z]))
    error=max(math.dist(a,b) for a,b in zip(points,truth))
    ply='ply\nformat ascii 1.0\nelement vertex '+str(len(points))+'\nproperty float x\nproperty float y\nproperty float z\nend_header\n'
    (out/'points.ply').write_text(ply+'\n'.join(' '.join(map(str,p)) for p in points))
    report={'synthetic':True,'points':len(points),'max_position_error':error,'units':'synthetic calibrated units','trained_model':False,'limitation':'Known cameras and exact correspondences; not reconstruction from real photographs.'}
    (out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
