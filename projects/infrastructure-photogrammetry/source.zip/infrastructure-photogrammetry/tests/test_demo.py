import unittest
from demo import triangulate
class TestDemo(unittest.TestCase):
 def test_metric_and_invalid_input(self):
  self.assertAlmostEqual(triangulate([0,0],[-100,0])[2],4); self.assertRaises(ValueError,triangulate,[0,0],[0,0])
