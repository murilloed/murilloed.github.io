# Inspeção digital de infraestrutura

Reconstruir estruturas a partir de fotografias para apoiar inspeções e medições.

## Implementação atual

Triangulação de pares estéreo calibrados, exportação PLY e plano de reconstrução COLMAP.

A demonstração usa pontos sintéticos e câmeras conhecidas; não treina redes neurais. Fotografias reais exigem calibração e referências de escala.

## Reproduzir a demonstração sintética

```bash
python demo.py
python -m unittest discover -s tests -v
```

A demonstração usa apenas a biblioteca padrão. O JSON identifica dados sintéticos e limitações. Não há métricas validadas em fotografias reais.

## Dados e treinamento

A demonstração usa pontos sintéticos e câmeras conhecidas; não treina redes neurais. Fotografias reais exigem calibração e referências de escala.

## Fluxo real opcional

Instale COLMAP seguindo a documentação oficial. Gere o plano sem executar:

```bash
python pipeline.py --images /caminho/fotos
```

Acrescente `--execute` para executar COLMAP. O pipeline gera reconstrução esparsa; malha, reconstrução densa e medições calibradas são próximas etapas. Para auditar uma exportação texto no projeto SfM, use `python demo.py --points points3D.txt`.

## Próximas etapas

Executar o fluxo em imagens autorizadas, separar avaliação, documentar falhas e publicar métricas reais.

## Referência técnica

[Documentação oficial](https://colmap.github.io/tutorial.html).
