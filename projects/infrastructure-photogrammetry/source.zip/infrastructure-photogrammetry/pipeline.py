"""Print or execute a sparse COLMAP pipeline on user-supplied images."""
import argparse,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--images',required=True);p.add_argument('--workspace',default='output/colmap');p.add_argument('--execute',action='store_true');a=p.parse_args()
images=Path(a.images).resolve();work=Path(a.workspace).resolve()
if not images.is_dir():p.error('Image directory must exist')
work.mkdir(parents=True,exist_ok=True);(work/'sparse').mkdir(exist_ok=True)
commands=[['colmap','feature_extractor','--database_path',str(work/'database.db'),'--image_path',str(images)],['colmap','exhaustive_matcher','--database_path',str(work/'database.db')],['colmap','mapper','--database_path',str(work/'database.db'),'--image_path',str(images),'--output_path',str(work/'sparse')]]
for command in commands:
 print(subprocess.list2cmdline(command))
 if a.execute:subprocess.run(command,check=True)
