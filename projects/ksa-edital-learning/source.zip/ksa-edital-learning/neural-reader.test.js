import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createNeuralReader,fitHead,predictHead} from './neural-reader.js';
const embed=async texts=>texts.map(t=>[t.length/100,...Array.from({length:7},(_,i)=>t.charCodeAt(i%t.length)/255)]);
test('supervised head learns separable classes',()=>{
 const head=fitHead([[1,0],[0,1],[-1,0]],[0,1,2]);
 assert.equal(predictHead(head,[1,0]).label,'specific');
 assert.equal(predictHead(head,[0,1]).label,'general');
});
test('reviewed correction persists and replaces duplicate labels',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'ksa-public-'));
 const reader=await createNeuralReader(dir,{embed});await reader.initialize();
 await reader.learn([{text:'Novo título sintético',label:'specific'}]);
 const old=JSON.parse(await readFile(path.join(dir,'aprendizado-editais.json'),'utf8'));
 await reader.learn([{text:'Novo título sintético',label:'general'}]);
 const saved=JSON.parse(await readFile(path.join(dir,'aprendizado-editais.json'),'utf8'));
 assert.equal(saved.examples.filter(e=>e.text==='Novo título sintético').length,1);
 assert.equal(saved.examples.at(-1).label,'general');
 assert.notDeepEqual(saved.head.w2,old.head.w2);
 const reopened=await createNeuralReader(dir,{embed});assert.equal(reopened.status().reviewedExamples,1);
 await assert.rejects(()=>reader.learn([{text:'Teste',label:'invalid'}]),/inválido/);
});
test('validation cannot leak into training and history survives restart',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'ksa-validation-'));
 const reader=await createNeuralReader(dir,{embed});await reader.initialize();
 await reader.reserve({text:'Título independente sintético',label:'general'});
 await assert.rejects(()=>reader.learn([{text:'Título independente sintético',label:'general'}]),/reservado/);
 await assert.rejects(()=>reader.reserve({text:'CONHECIMENTOS ESPECÍFICOS',label:'specific'}),/já está/);
 await reader.learn([{text:'Seção sintética revisada',label:'specific'}]);
 const report=await reader.report();
 assert.equal(report.training.total,36);assert.equal(report.validation.total,1);assert.equal(report.history.length,1);
 const reopened=await createNeuralReader(dir,{embed});
 assert.deepEqual((await reopened.report()).history,report.history);
});
