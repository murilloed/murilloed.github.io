# IA–KSA — aprendizagem supervisionada de editais

Módulo público isolado do leitor neural do projeto IA - KSA - Competency-Based Management (I-Comp). Não inclui o perfil pessoal, editais enviados, exemplos corrigidos pelo usuário, pesos pessoais, modelos de terceiros ou o restante da aplicação.

## Objetivo e entrega
Classificar títulos de seções de editais e incorporar exemplos revisados a uma base persistente. Seis classes: conhecimentos específicos, conhecimentos gerais, prova, inscrição, cargo/perfil e outros.

## Como aprende
O encoder pré-treinado Xenova/multilingual-e5-small gera embeddings de 384 dimensões, em CPU e ONNX quantizado. Uma cabeça neural 384 → 24 → 6 usa tanh e softmax, gradientes de entropia cruzada, 180 épocas e taxa 0,09. O encoder permanece congelado. Após confirmação humana, os exemplos são adicionados/corrigidos e a cabeça é retreinada do zero com a base acumulada. Importar um edital não o torna automaticamente um exemplo correto.

## Executar
```bash
npm install
npm test
npm run demo
```
O primeiro uso baixa o encoder público; posteriormente usa o cache local em models/. O exemplo gera dados sintéticos de títulos e grava output/report.json. Uma pasta de cache já existente pode ser informada com `npm run demo -- --model-dir /caminho/models`.

## Validação
Os testes de persistência usam embeddings simulados e não medem qualidade semântica. A demonstração usa o encoder real e quatro títulos sintéticos reservados para validação. Não confundir desempenho no treino com generalização ou extrapolar essa amostra para editais reais.

## Limites
Este módulo classifica títulos; não extrai sozinho todo o edital, não infere competências ausentes e não garante associação entre disciplinas e cargos. A aplicação original combina classificação com leitura estrutural e evidências literais. Documentos digitalizados precisam de OCR externo. Cada atualização exige revisão e não garante melhora. O repositório demonstra aprendizagem acumulativa supervisionada, não treinamento contínuo do encoder.

Modelo de terceiros: https://huggingface.co/Xenova/multilingual-e5-small
