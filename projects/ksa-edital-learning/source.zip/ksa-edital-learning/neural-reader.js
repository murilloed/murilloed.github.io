import { mkdir, readFile, writeFile, rename, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
export const neuralLabels = ['specific','general','exam','registration','role','other'];
const seeds = {
 specific:['CONHECIMENTOS ESPECÍFICOS','MÓDULO II – CONHECIMENTOS ESPECÍFICOS','Conteúdo específico do cargo','Disciplinas especializadas','Conhecimentos profissionais'],
 general:['CONHECIMENTOS GERAIS PARA TODOS OS CARGOS','Conhecimentos básicos comuns a todos','Disciplinas comuns aos cargos','MÓDULO I – CONHECIMENTOS GERAIS','Conteúdo geral das provas'],
 exam:['Aplicação das provas objetivas','Data da prova objetiva','Aplicação da prova objetiva para o cargo','Realização das provas escritas','Provas objetiva e discursiva'],
 registration:['Período de solicitação de inscrições','Inscrições abertas no período','Início das inscrições','Fim das inscrições','Período de inscrição no concurso'],
 role:['CARGO 1: ANALISTA','PERFIL 2: ENGENHARIA','Cargo de agente de polícia','Perfil profissional: desenvolvimento de software','Emprego: técnico administrativo'],
 other:['Prazo de recursos','Resultados preliminares','REMUNERAÇÃO','Pagamento da taxa de inscrição','LÍNGUA PORTUGUESA: 1 Interpretação','Requisitos para contratação','Consulta aos gabaritos','ATUALIDADES','Disposições finais','Resultado da isenção de taxa']
};
const seedExamples=Object.entries(seeds).flatMap(([label,texts])=>texts.map(text=>({text,label,source:'base revisada'})));
function createHead(dims,hidden=24){let n=37;const rand=()=>{n=(n*1664525+1013904223)>>>0;return (n/4294967296-.5)*.12;};return {dims,hidden,w1:Array.from({length:dims*hidden},rand),b1:Array(hidden).fill(0),w2:Array.from({length:hidden*neuralLabels.length},rand),b2:Array(neuralLabels.length).fill(0)};}
function forward(head,x){const h=head.b1.map((b,j)=>Math.tanh(x.reduce((s,v,k)=>s+v*head.w1[j*head.dims+k],b)));const z=head.b2.map((b,j)=>h.reduce((s,v,k)=>s+v*head.w2[j*head.hidden+k],b));const max=Math.max(...z),p=z.map(v=>Math.exp(v-max)),sum=p.reduce((a,b)=>a+b,0);return {h,p:p.map(v=>v/sum)};}
export function fitHead(vectors,labels){const head=createHead(vectors[0].length);for(let epoch=0;epoch<180;epoch++)for(let i=0;i<vectors.length;i++){const x=vectors[i],{h,p}=forward(head,x),dy=p.map((v,j)=>v-(j===labels[i]?1:0));const dh=h.map((v,k)=>dy.reduce((s,e,j)=>s+e*head.w2[j*head.hidden+k],0)*(1-v*v));const rate=.09;for(let j=0;j<dy.length;j++){head.b2[j]-=rate*dy[j];for(let k=0;k<head.hidden;k++)head.w2[j*head.hidden+k]-=rate*dy[j]*h[k];}for(let j=0;j<head.hidden;j++){head.b1[j]-=rate*dh[j];for(let k=0;k<head.dims;k++)head.w1[j*head.dims+k]-=rate*dh[j]*x[k];}}return head;}
export function predictHead(head,vector){const {p}=forward(head,vector),index=p.indexOf(Math.max(...p));return {label:neuralLabels[index],score:p[index]};}

export async function createNeuralReader(dataDir,{modelDir=path.resolve('models'),embed=null}={}) {
 await mkdir(dataDir,{recursive:true});const filename=path.join(dataDir,'aprendizado-editais.json');
 let state={version:1,model:'Xenova/multilingual-e5-small',examples:seedExamples,head:null,trainedAt:null},status='Modelo ainda não carregado',extractor=null,initializing=null,queue=Promise.resolve();
 try{const saved=JSON.parse(await readFile(filename,'utf8'));if(saved.version===1&&saved.model===state.model&&Array.isArray(saved.examples)){state={...saved,validation:saved.validation||[],history:saved.history||[]};status='Modelo instalado · carregamento sob demanda';}}catch(e){if(e.code!=='ENOENT')throw e;}
 async function vectors(texts){if(embed)return embed(texts);if(!extractor){const {pipeline,env}=await import('@huggingface/transformers');env.cacheDir=modelDir;extractor=await pipeline('feature-extraction',state.model,{dtype:'q8',device:'cpu'});}const result=[];for(let i=0;i<texts.length;i+=8){const output=await extractor(texts.slice(i,i+8).map(t=>'query: '+t),{pooling:'mean',normalize:true});result.push(...output.tolist());}return result;}
 async function persist(){try{await copyFile(filename,filename+'.bak');}catch(e){if(e.code!=='ENOENT')throw e;}await writeFile(filename+'.tmp',JSON.stringify(state));for(let attempt=0;;attempt++){try{await rename(filename+'.tmp',filename);break;}catch(e){if(!['EPERM','EBUSY'].includes(e.code)||attempt>=5)throw e;await delay(20*2**attempt);}}}
 async function initialize(){if(!initializing)initializing=(async()=>{status='Carregando modelo neural local…';if(!state.head){const v=await vectors(state.examples.map(e=>e.text));state.head=fitHead(v,state.examples.map(e=>neuralLabels.indexOf(e.label)));state.trainedAt=new Date().toISOString();await persist();}else if(!embed)await vectors(['Verificação do modelo local']);status='Modelo neural local ativo';})().catch(e=>{status='Modelo indisponível: '+e.message;initializing=null;throw e;});return initializing;}
 function cleanExample(e){if(typeof e.text!=='string'||!e.text.trim()||e.text.length>1000||!neuralLabels.includes(e.label))throw Error('Exemplo de aprendizagem inválido.');return {text:e.text.trim(),label:e.label,source:'confirmado pelo usuário'};}
 async function measure(examples){if(!examples.length)return {total:0,correct:0,accuracy:null,rows:[]};const v=await vectors(examples.map(e=>e.text));const rows=examples.map((e,i)=>({...e,...Object.fromEntries(Object.entries(predictHead(state.head,v[i])).map(([k,x])=>[k==='label'?'predicted':k,x]))}));const correct=rows.filter(e=>e.label===e.predicted).length;return {total:rows.length,correct,accuracy:correct/rows.length,rows};}
 async function report(){await queue;await initialize();return {...this.status(),files:{learning:filename,backup:filename+'.bak',models:modelDir},training:await measure(state.examples),validation:await measure(state.validation||[]),history:state.history||[],classes:Object.fromEntries(neuralLabels.map(l=>[l,state.examples.filter(e=>e.label===l).length]))};}
 function manage(input){const operation=queue.then(async()=>{
  await initialize();let examples=[...state.examples],validation=[...(state.validation||[])];
  if(input.operation==='remove'){
   if(!['training','validation'].includes(input.purpose)||typeof input.text!=='string')throw Error('Artefato inválido.');
   if(input.purpose==='training')examples=examples.filter(e=>e.text!==input.text);else validation=validation.filter(e=>e.text!==input.text);
  }else if(input.operation==='import'){
   const data=input.dataset;if(!data||!Array.isArray(data.examples)||!Array.isArray(data.validation||[]))throw Error('Use JSON com examples e validation.');
   for(const [list,entries] of [[examples,data.examples],[validation,data.validation||[]]])for(const item of entries){const e=cleanExample(item);const index=list.findIndex(x=>x.text===e.text);if(index<0)list.push(e);else list[index]=e;}
  }else throw Error('Operação inválida.');
  if(!examples.length||examples.length>1000||validation.length>200)throw Error('Mantenha de 1 a 1.000 exemplos de treino e até 200 de validação.');
  if(validation.some(v=>examples.some(e=>e.text===v.text)))throw Error('O mesmo título não pode estar no treino e na validação.');
  const before=await measure(validation),started=Date.now(),oldHead=JSON.stringify(state.head);
  const head=fitHead(await vectors(examples.map(e=>e.text)),examples.map(e=>neuralLabels.indexOf(e.label)));
  state={...state,examples,validation,head,trainedAt:new Date().toISOString()};
  const after=await measure(validation);const event={at:state.trainedAt,operation:input.operation,examples:examples.length,weightsChanged:oldHead!==JSON.stringify(head),durationMs:Date.now()-started,validationTotal:validation.length,beforeAccuracy:before.accuracy,afterAccuracy:after.accuracy};
  state.history=[...(state.history||[]),event].slice(-100);await persist();return event;
 });queue=operation.catch(()=>{});return operation;}
 return {
  initialize,
  async artifacts(){await queue;return structuredClone(state);},
  manage,
  recordNeeds(record){const operation=queue.then(async()=>{state={...state,learningNeeds:[...(state.learningNeeds||[]).filter(r=>r.contestId!==record.contestId),record].slice(-100)};await persist();});queue=operation.catch(()=>{});return operation;},
  report,
  status:()=>({status,model:state.model,examples:state.examples.length,reviewedExamples:state.examples.filter(e=>e.source!=='base revisada').length,trainedAt:state.trainedAt}),
  async classify(texts){await queue;await initialize();const v=await vectors(texts);return v.map((x,i)=>({text:texts[i],...predictHead(state.head,x)}));},
  learn(examples){const operation=queue.then(async()=>{const clean=examples.map(cleanExample);if(!clean.length)throw Error('Nenhum exemplo para aprender.');await initialize();const next=[...state.examples];for(const e of clean){if((state.validation||[]).some(v=>v.text===e.text))throw Error('Título reservado para validação; use outro título para ensinar.');const old=next.findIndex(x=>x.text===e.text);if(old>=0)next[old]=e;else next.push(e);}if(next.length>1000)throw Error('Limite de 1.000 exemplos atingido.');const started=Date.now(),before=await measure(state.validation||[]),oldHead=JSON.stringify(state.head);const v=await vectors(next.map(e=>e.text));const head=fitHead(v,next.map(e=>neuralLabels.indexOf(e.label)));state={...state,examples:next,head,trainedAt:new Date().toISOString()};const after=await measure(state.validation||[]);const event={at:state.trainedAt,examples:next.length,submitted:clean.length,weightsChanged:JSON.stringify(head)!==oldHead,durationMs:Date.now()-started,validationTotal:after.total,beforeAccuracy:before.accuracy,afterAccuracy:after.accuracy};state.history=[...(state.history||[]),event].slice(-100);await persist();return {...event,trainedAt:state.trainedAt};});queue=operation.catch(()=>{});return operation;},
  reserve(example){const operation=queue.then(async()=>{const e=cleanExample(example);if(state.examples.some(x=>x.text===e.text))throw Error('Este título já está no treino. Escolha um título novo para uma validação independente.');const next=[...(state.validation||[])].filter(x=>x.text!==e.text);if(next.length>=200)throw Error('Limite de 200 títulos de validação atingido.');next.push(e);state={...state,validation:next};await persist();return {validationExamples:next.length};});queue=operation.catch(()=>{});return operation;},
  async analyze(text,analyzer,options){
   try{const candidates=[...new Set(text.split('\n').map(t=>t.trim()).filter(t=>t.length>8&&t.length<280&&(/^[\d.]*\s*[A-ZÀ-Ú][A-ZÀ-Ú\s\d():/–—-]+$/.test(t)||/^Aplicação|^Período/i.test(t))))].slice(0,100);
    const labels=candidates.length?await this.classify(candidates):[];
    const sectionLabels=Object.fromEntries(labels.filter(l=>l.score>=.80).map(l=>[l.text.replace(/^\d+(?:\.\d+)*\s+/,'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(),l.label]));
    const result=analyzer(text,{...options,sectionLabels});result.neuralAnalysis={model:state.model,status:'active',reviewedExamples:this.status().reviewedExamples,sectionsRecognized:labels.filter(l=>l.score>=.80).length};return result;
   }catch(e){const result=analyzer(text,options);result.neuralAnalysis={model:state.model,status:'unavailable',reviewedExamples:this.status().reviewedExamples,sectionsRecognized:0};result.warnings.push('Modelo neural indisponível; leitura estrutural utilizada. '+e.message.slice(0,180));return result;}
  }
 };
}
