import {createNeuralReader} from './neural-reader.js';
import {mkdir,writeFile,mkdtemp} from 'node:fs/promises';
import path from 'node:path';
const index=process.argv.indexOf('--model-dir');
const modelDir=index>=0?path.resolve(process.argv[index+1]):path.resolve('models');
await mkdir('output',{recursive:true});
const dataDir=await mkdtemp(path.resolve('output/run-'));
const reader=await createNeuralReader(dataDir,{modelDir});
await reader.initialize();
const validation=[
 {text:'Prazo para inscrição no certame demonstrativo',label:'registration'},
 {text:'Data de aplicação do exame demonstrativo',label:'exam'},
 {text:'Conteúdos especializados da função demonstrativa',label:'specific'},
 {text:'Conhecimentos comuns aos perfis demonstrativos',label:'general'}
];
for(const example of validation)await reader.reserve(example);
const before=await reader.report();
const update=await reader.learn([
 {text:'Conteúdo específico da função de analista demonstrativo',label:'specific'},
 {text:'Período para inscrição de candidatos do exemplo',label:'registration'}
]);
const after=await reader.report();
const reopened=await createNeuralReader(dataDir,{modelDir});
const report={
 synthetic:true,encoder:'Xenova/multilingual-e5-small',encoderFrozen:true,
 architecture:[384,24,6],epochs:180,learningRate:0.09,
 reviewedUpdate:{submitted:update.submitted,weightsChanged:update.weightsChanged},
 examples:{before:before.training.total,after:after.training.total,validation:after.validation.total},
 validation:{before:before.validation,after:after.validation},
 persistence:{restoredExamples:reopened.status().examples},
 limitation:'Tiny synthetic sample; does not establish accuracy on real notices. Imports require review before learning; the encoder is not retrained.'
};
await writeFile('output/report.json',JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
