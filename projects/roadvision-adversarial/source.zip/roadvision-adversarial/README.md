# Visão robusta para pavimentos

Classificação visual e avaliação sob perturbações adversariais.

**Status: MVP de pesquisa, v0.1.0.** Estudo de caso independente inspirado
em desafios dos setores relacionados à trajetória do autor (Grupo CCR · Detran-DF).
Não representa entrega contratada, resultado real ou endosso dessas organizações.
Todos os exemplos desta versão são sintéticos e reproduzíveis.

## Executar

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e .
python -m roadvision.demo --epochs 5 --seed 7
python -m unittest discover -s tests -v
```

## Implementado

Dataset sintético de pavimentos, divisão por imagem-base, CNN e ResNet próprias; treinamento limpo e adversarial; FGSM e PGD com projeção L∞; relatório de accuracy e macro-F1 em holdout sintético.

## Próximas etapas

Dataset real com licença; transferência de aprendizado; segmentação; múltiplas sementes; avaliação por trecho de estrada; GPU e monitoramento de drift.

## Reprodutibilidade e avaliação

A demonstração grava `artifacts/report.json`, com parâmetros e métricas.
Resultados de dados sintéticos validam o fluxo; não demonstram desempenho em produção.
Use a mesma semente e orçamento computacional para comparar abordagens.
Consulte `docs/design.md` para decisões e limitações.

## Contribuição

Abra uma issue com objetivo e critério de aceite. Entregue mudanças pequenas,
revisadas e acompanhadas de testes de comportamento. Não inclua dados de clientes,
credenciais ou resultados sem proveniência. Licença MIT para código e dados sintéticos próprios.
