# Decisões de engenharia

## Escopo
Classificação visual e avaliação sob perturbações adversariais. O cenário é um benchmark sintético independente.

## Entregas atuais
Dataset sintético de pavimentos, divisão por imagem-base, CNN e ResNet próprias; treinamento limpo e adversarial; FGSM e PGD com projeção L∞; relatório de accuracy e macro-F1 em holdout sintético.

## Evolução
Dataset real com licença; transferência de aprendizado; segmentação; múltiplas sementes; avaliação por trecho de estrada; GPU e monitoramento de drift.

## Qualidade e colaboração
CI executa testes de comportamento. Revisões devem conferir contratos de entrada,
invariantes, divisão de dados e métricas. Evoluções de infraestrutura exigem avaliação
de custo, autorização e observabilidade. Não há recursos cloud provisionados.

## Limitações
Validar a hipótese com dados públicos licenciados ou dados autorizados antes de uso
operacional. Relatar baseline, várias sementes, intervalos de incerteza, consumo
de recursos e resultados negativos. O backlog não constitui funcionalidade implementada.
