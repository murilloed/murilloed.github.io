import torch
from torch import nn

class Block(nn.Module):
    def __init__(self,c):
        super().__init__()
        self.layers=nn.Sequential(nn.Conv2d(c,c,3,padding=1),nn.ReLU(),nn.Conv2d(c,c,3,padding=1))
    def forward(self,x): return torch.relu(x+self.layers(x))

class Classifier(nn.Module):
    def __init__(self,residual=True):
        super().__init__()
        self.features=nn.Sequential(nn.Conv2d(1,8,3,padding=1),nn.ReLU(),
            Block(8) if residual else nn.Conv2d(8,8,3,padding=1),nn.ReLU(),
            nn.AdaptiveAvgPool2d(1))
        self.head=nn.Linear(8,2)
    def forward(self,x): return self.head(self.features(x).flatten(1))

def attack(model,x,y,epsilon=.1,steps=5,alpha=.03):
    if epsilon<0 or steps<1: raise ValueError('invalid attack bounds')
    base=x.detach(); z=base.clone()
    for _ in range(steps):
        z=z.detach().requires_grad_(True)
        loss=nn.functional.cross_entropy(model(z),y)
        grad=torch.autograd.grad(loss,z)[0]
        z=z.detach()+alpha*grad.sign()
        z=torch.maximum(torch.minimum(z,base+epsilon),base-epsilon).clamp(0,1)
    return z.detach()
