import argparse, json
from pathlib import Path
import numpy as np
import torch
from torch import nn
from .model import Classifier, attack

def data(seed,n=160):
    rng=np.random.default_rng(seed); x=rng.uniform(.45,.7,(n,1,24,24)).astype('float32')
    y=np.arange(n)%2
    for i in range(n):
        if y[i]:
            col=int(rng.integers(3,20)); x[i,0,:,col:col+2]=rng.uniform(.05,.2)
    return torch.tensor(x),torch.tensor(y,dtype=torch.long)

def metrics(model,x,y):
    with torch.no_grad(): pred=model(x).argmax(1)
    f=[]
    for c in range(2):
        tp=((pred==c)&(y==c)).sum().item(); fp=((pred==c)&(y!=c)).sum().item()
        fn=((pred!=c)&(y==c)).sum().item(); f.append(2*tp/max(1,2*tp+fp+fn))
    return {'accuracy':float((pred==y).float().mean()),'macro_f1':sum(f)/2}

def train(x,y,epochs,residual,adversarial,seed):
    torch.manual_seed(seed); model=Classifier(residual); opt=torch.optim.Adam(model.parameters(),lr=.005)
    for _ in range(epochs):
        for idx in torch.randperm(len(y)).split(32):
            bx,by=x[idx],y[idx]
            if adversarial:
                attacked=attack(model,bx,by,steps=3)
                bx=torch.cat([bx,attacked]); by=torch.cat([by,by])
            loss=nn.functional.cross_entropy(model(bx),by)
            opt.zero_grad(); loss.backward(); opt.step()
    return model

def main():
    p=argparse.ArgumentParser(); p.add_argument('--epochs',type=int,default=5); p.add_argument('--seed',type=int,default=7)
    a=p.parse_args()
    if a.epochs<1: p.error('epochs must be positive')
    torch.set_num_threads(1); x,y=data(a.seed); tx,ty=data(a.seed+100,60)
    results={}; last=None
    for name,res,adv in [('cnn',False,False),('resnet',True,False),('resnet_adversarial',True,True)]:
        model=train(x,y,a.epochs,res,adv,a.seed); model.eval()
        results[name]={'clean':metrics(model,tx,ty),
                       'fgsm':metrics(model,attack(model,tx,ty,steps=1,alpha=.1),ty),
                       'pgd':metrics(model,attack(model,tx,ty),ty)}
        last=model
    report={'synthetic':True,'seed':a.seed,'epochs':a.epochs,'train_images':len(y),
            'test_images':len(ty),'epsilon_linf':.1,'models':results}
    Path('artifacts').mkdir(exist_ok=True)
    Path('artifacts/report.json').write_text(json.dumps(report,indent=2))
    torch.save(last.state_dict(),'artifacts/resnet-adversarial.pt')
    from PIL import Image
    Image.fromarray((tx[1,0].numpy()*255).astype('uint8')).resize((288,288)).save('artifacts/sample.png')
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()
