import unittest, torch
from roadvision.model import Classifier, attack
class Tests(unittest.TestCase):
    def test_pgd_projected_and_zero_attack_identity(self):
        torch.manual_seed(1); m=Classifier(); x=torch.rand(3,1,24,24); y=torch.tensor([0,1,0])
        z=attack(m,x,y,epsilon=.07)
        self.assertLessEqual(float((z-x).abs().max()),.070001)
        self.assertTrue(bool(((z>=0)&(z<=1)).all()))
        self.assertTrue(torch.equal(attack(m,x,y,epsilon=0),x))
