"""Independent environmental image comparison demo."""
