# Mapeamento 3D de áreas com erosão

Organizar a reconstrução de áreas com erosão para estudar sua geometria.

## Implementação atual

Pipeline COLMAP de extração, correspondência e reconstrução; auditoria de pontos e erro de reprojeção.

SfM ajusta câmeras e pontos, sem treinamento supervisionado. A auditoria demonstrativa usa uma exportação COLMAP sintética; o pipeline em fotos reais ainda precisa ser executado.

## Reproduzir a demonstração sintética

```bash
python demo.py
python -m unittest discover -s tests -v
```

A demonstração usa apenas a biblioteca padrão. O JSON identifica dados sintéticos e limitações. Não há métricas validadas em fotografias reais.

## Dados e treinamento

SfM ajusta câmeras e pontos, sem treinamento supervisionado. A auditoria demonstrativa usa uma exportação COLMAP sintética; o pipeline em fotos reais ainda precisa ser executado.

## Fluxo real opcional

Instale COLMAP seguindo a documentação oficial. Gere o plano sem executar:

```bash
python pipeline.py --images /caminho/fotos
```

Acrescente `--execute` para executar COLMAP. O pipeline gera reconstrução esparsa; malha, reconstrução densa e medições calibradas são próximas etapas. Para auditar uma exportação texto no projeto SfM, use `python demo.py --points points3D.txt`.

## Próximas etapas

Executar o fluxo em imagens autorizadas, separar avaliação, documentar falhas e publicar métricas reais.

## Referência técnica

[Documentação oficial](https://colmap.github.io/tutorial.html).
