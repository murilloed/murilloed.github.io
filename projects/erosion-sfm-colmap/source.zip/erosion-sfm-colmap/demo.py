import argparse,json
from pathlib import Path

def audit(text):
    rows=[]
    for line in text.splitlines():
        if not line.strip() or line.startswith('#'):continue
        parts=line.split()
        if len(parts)<10 or (len(parts)-8)%2:raise ValueError('Invalid COLMAP points3D row')
        error=float(parts[7]);track=(len(parts)-8)//2
        if error<0:raise ValueError('Negative reprojection error')
        rows.append((error,track))
    return {'points':len(rows),'mean_reprojection_error_px':sum(r[0] for r in rows)/len(rows) if rows else None,'observations':sum(r[1] for r in rows)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--points');p.add_argument('--output',default='output');a=p.parse_args();o=Path(a.output);o.mkdir(parents=True,exist_ok=True)
    text=Path(a.points).read_text() if a.points else '# Synthetic COLMAP export\n1 0 0 1 255 0 0 0.4 1 0 2 0\n2 1 0 1 0 255 0 0.8 1 1 2 1 3 0\n'
    r={'synthetic':not bool(a.points),'metrics':audit(text),'trained_model':False,'limitation':'Audit only; does not estimate camera poses or verify erosion in real terrain.'};(o/'report.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
if __name__=='__main__':main()
