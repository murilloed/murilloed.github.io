import unittest
from demo import audit
class TestDemo(unittest.TestCase):
 def test_metric_and_invalid_input(self):
  self.assertEqual(audit('1 0 0 1 0 0 0 0.5 1 0 2 0')['observations'],2); self.assertRaises(ValueError,audit,'bad')
