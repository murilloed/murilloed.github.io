# Layouts industriais generativos

Geração adversarial de layouts com validação geométrica.

**Status: MVP de pesquisa, v0.1.0.** Estudo de caso independente inspirado
em desafios dos setores relacionados à trajetória do autor (Marcopolo).
Não representa entrega contratada, resultado real ou endosso dessas organizações.
Todos os exemplos desta versão são sintéticos e reproduzíveis.

## Executar

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e .
python -m layoutgan.demo --steps 100 --seed 7
python -m unittest discover -s tests -v
```

## Implementado

GAN condicional para coordenadas de três equipamentos; treino gerador/discriminador com penalidades geométricas e condicionais; dados sintéticos; verificador independente de limites, corredor e sobreposição; baseline aleatório; exportação SVG.

## Próximas etapas

Treinamento com mais dados e múltiplas sementes; diversidade e cobertura; geração raster com CNN; correção por solver; DXF e integração Autodesk; restrições validadas por especialista.

## Reprodutibilidade e avaliação

A demonstração grava `artifacts/report.json`, com parâmetros e métricas.
Resultados de dados sintéticos validam o fluxo; não demonstram desempenho em produção.
Use a mesma semente e orçamento computacional para comparar abordagens.
Consulte `docs/design.md` para decisões e limitações.

## Contribuição

Abra uma issue com objetivo e critério de aceite. Entregue mudanças pequenas,
revisadas e acompanhadas de testes de comportamento. Não inclua dados de clientes,
credenciais ou resultados sem proveniência. Licença MIT para código e dados sintéticos próprios.
