import unittest
from layoutgan.core import feasible,synthetic
class Tests(unittest.TestCase):
    def test_reference_layouts(self):
        x,_=synthetic(30,7); self.assertTrue(all(feasible(s) for s in x.numpy()))
    def test_overlap_corridor_and_bounds(self):
        self.assertFalse(feasible([.1,.1,.1,.1,.1,.1]))
        self.assertFalse(feasible([.1,.4,.4,.1,.7,.1]))
        self.assertFalse(feasible([.95,.1,.4,.1,.7,.1]))
