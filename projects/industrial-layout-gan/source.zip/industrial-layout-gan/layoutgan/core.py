import numpy as np
import torch
from torch import nn

def feasible(flat,width=.16,height=.18):
    p=np.asarray(flat).reshape(3,2)
    if not np.isfinite(p).all() or (p<0).any() or (p[:,0]+width>1).any() or (p[:,1]+height>1).any():
        return False
    # Central horizontal corridor is reserved: y in [.44,.56].
    for x,y in p:
        if y<.56 and y+height>.44: return False
    for i in range(3):
        for j in range(i):
            if abs(p[i,0]-p[j,0])<width and abs(p[i,1]-p[j,1])<height: return False
    return True

def synthetic(n,seed):
    rng=np.random.default_rng(seed); layouts=[]; conditions=[]
    # Condition 0: lower row; condition 1: upper row.
    for _ in range(n):
        c=int(rng.integers(2)); p=np.array([[.07,.12],[.38,.12],[.68,.12]])
        p[:,1]+=.52*c; p+=rng.uniform(-.025,.025,(3,2))
        layouts.append(p.reshape(-1)); conditions.append([c])
    return torch.tensor(np.array(layouts),dtype=torch.float32),torch.tensor(conditions,dtype=torch.float32)

class Generator(nn.Module):
    def __init__(self):
        super().__init__(); self.net=nn.Sequential(nn.Linear(9,32),nn.ReLU(),nn.Linear(32,6),nn.Sigmoid())
    def forward(self,z,c): return self.net(torch.cat([z,c],1))

class Discriminator(nn.Module):
    def __init__(self):
        super().__init__(); self.net=nn.Sequential(nn.Linear(7,32),nn.LeakyReLU(.2),nn.Linear(32,1))
    def forward(self,x,c): return self.net(torch.cat([x,c],1))

def train(steps,seed):
    torch.manual_seed(seed); torch.set_num_threads(1)
    g,d=Generator(),Discriminator(); go=torch.optim.Adam(g.parameters(),lr=.003)
    do=torch.optim.Adam(d.parameters(),lr=.003); loss=nn.BCEWithLogitsLoss()
    real,c=synthetic(256,seed)
    for _ in range(steps):
        idx=torch.randint(0,len(real),(32,)); bx,bc=real[idx],c[idx]
        fake=g(torch.randn(32,8),bc)
        dl=loss(d(bx,bc),torch.ones(32,1))+loss(d(fake.detach(),bc),torch.zeros(32,1))
        do.zero_grad(); dl.backward(); do.step()
        proposal=g(torch.randn(32,8),bc)
        coords=proposal.reshape(-1,3,2)
        # Differentiable penalties guide training; the independent verifier
        # remains the authority for feasibility at inference.
        bounds=torch.relu(coords[:,:,0]+.16-1).mean()+torch.relu(coords[:,:,1]+.18-1).mean()
        corridor=(torch.relu(.56-coords[:,:,1])*torch.relu(coords[:,:,1]+.18-.44)).mean()
        overlaps=sum((torch.relu(.16-(coords[:,i,0]-coords[:,j,0]).abs())*
                      torch.relu(.18-(coords[:,i,1]-coords[:,j,1]).abs())).mean()
                     for i in range(3) for j in range(i))
        condition_target=.12+.52*bc
        alignment=(coords[:,:,1]-condition_target).square().mean()
        gl=loss(d(proposal,bc),torch.ones(32,1))+10*(bounds+overlaps)+40*corridor+5*alignment
        go.zero_grad(); gl.backward(); go.step()
    return g,{'generator_loss':float(gl.detach()),'discriminator_loss':float(dl.detach())}

def svg(flat):
    parts=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400">',
           '<rect width="600" height="400" fill="#0b1c33"/>',
           '<rect x="0" y="176" width="600" height="48" fill="#24415e"/>']
    for i,(x,y) in enumerate(np.asarray(flat).reshape(3,2)):
        parts.append(f'<rect x="{x*600:.1f}" y="{y*400:.1f}" width="96" height="72" fill="#2de2e6"/>')
        parts.append(f'<text x="{x*600+8:.1f}" y="{y*400+25:.1f}" fill="#071121">M{i+1}</text>')
    return ''.join(parts)+'</svg>'
