import argparse,json
from pathlib import Path
import numpy as np
import torch
from .core import train,feasible,synthetic,svg
def main():
    p=argparse.ArgumentParser(); p.add_argument('--steps',type=int,default=100); p.add_argument('--seed',type=int,default=7)
    a=p.parse_args()
    if a.steps<1: p.error('steps must be positive')
    g,losses=train(a.steps,a.seed)
    with torch.no_grad(): samples=g(torch.randn(100,8),torch.zeros(100,1)).numpy()
    rng=np.random.default_rng(a.seed); random=rng.uniform(0,.8,(100,6))
    valid=[s for s in samples if feasible(s)]
    fallback,_=synthetic(1,a.seed)
    display=valid[0] if valid else fallback[0].numpy()
    report={'synthetic':True,'seed':a.seed,'steps':a.steps,'losses':losses,
            'gan_feasible_rate':len(valid)/100,'random_feasible_rate':sum(feasible(s) for s in random)/100,
                'mean_coordinate_std':float(samples.std(axis=0).mean()),
                'svg_source':'generated' if valid else 'synthetic reference; GAN produced no feasible sample',
            'limitations':'Short training; feasibility is not guaranteed; condition fidelity not yet evaluated.'}
    Path('artifacts').mkdir(exist_ok=True)
    Path('artifacts/layout.svg').write_text(svg(display)); Path('artifacts/report.json').write_text(json.dumps(report,indent=2))
    torch.save(g.state_dict(),'artifacts/generator.pt'); print(json.dumps(report,indent=2))
if __name__=='__main__': main()
