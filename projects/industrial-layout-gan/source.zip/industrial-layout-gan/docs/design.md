# Decisões de engenharia

## Escopo
Geração adversarial de layouts com validação geométrica. O cenário é um benchmark sintético independente.

## Entregas atuais
GAN condicional para coordenadas de três equipamentos; treino gerador/discriminador com penalidades geométricas e condicionais; dados geométricos sintéticos; verificador independente de limites, corredor e sobreposição; baseline aleatório; exportação SVG.

## Evolução
Treinamento com mais dados e múltiplas sementes; diversidade e cobertura; geração raster com CNN; correção por solver; DXF e integração Autodesk; restrições validadas por especialista.

## Qualidade e colaboração
CI executa testes de comportamento. Revisões devem conferir contratos de entrada,
invariantes, divisão de dados e métricas. Evoluções de infraestrutura exigem avaliação
de custo, autorização e observabilidade. Não há recursos cloud provisionados.

## Limitações
Validar a hipótese com dados públicos licenciados ou dados autorizados antes de uso
operacional. Relatar baseline, várias sementes, intervalos de incerteza, consumo
de recursos e resultados negativos. O backlog não constitui funcionalidade implementada.
