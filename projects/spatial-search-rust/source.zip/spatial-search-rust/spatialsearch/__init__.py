"""Independent reproducible portfolio study."""
