# Profundidade e segmentação de vias e ambientes

Separar regiões da cena e comparar sua profundidade relativa.

## Implementação atual

Estatísticas por classe, profundidade relativa e adaptador opcional de inferência com modelos pré-treinados.

A demonstração usa mapas sintéticos. O adaptador usa modelos prontos, sem fine-tuning; a execução com imagens reais e avaliação por classe ainda são próximas etapas.

## Reproduzir a demonstração sintética

```bash
python demo.py
python -m unittest discover -s tests -v
```

A demonstração usa apenas a biblioteca padrão. O JSON identifica dados sintéticos e limitações. Não há métricas validadas em fotografias reais.

## Dados e treinamento

A demonstração usa mapas sintéticos. O adaptador usa modelos prontos, sem fine-tuning; a execução com imagens reais e avaliação por classe ainda são próximas etapas.

## Fluxo real opcional

Inferência opcional (não executada nesta publicação):

```bash
python -m pip install torch transformers pillow
python infer.py /caminho/imagem.jpg
```

Os modelos são baixados na primeira execução. As classes seguem o vocabulário ADE20K do modelo, sem adaptação específica ao Cerrado ou a vias. O mapa de profundidade é relativo e normalizado, sem distância métrica.

## Próximas etapas

Executar o fluxo em imagens autorizadas, separar avaliação, documentar falhas e publicar métricas reais.

## Referência técnica

[Documentação oficial](https://huggingface.co/docs/transformers/model_doc/depth_anything).
