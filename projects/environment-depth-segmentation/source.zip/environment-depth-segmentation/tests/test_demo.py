import unittest
from demo import summarize
class TestDemo(unittest.TestCase):
 def test_metric_and_invalid_input(self):
  self.assertEqual(summarize(['a','a','b'],[1,3,4])['a']['mean_relative_depth'],2); self.assertRaises(ValueError,summarize,['a'],[])
