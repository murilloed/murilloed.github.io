import argparse,json,math
from pathlib import Path

def summarize(labels,depth):
    if not labels or len(labels)!=len(depth):raise ValueError('Equal nonempty maps required')
    if any(not math.isfinite(float(d)) for d in depth):raise ValueError('Finite depth required')
    result={}
    for label in sorted(set(labels)):
        values=[d for l,d in zip(labels,depth) if l==label]
        result[label]={'pixels':len(values),'coverage_percent':100*len(values)/len(labels),'mean_relative_depth':sum(values)/len(values)}
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',default='output');a=p.parse_args();o=Path(a.output);o.mkdir(parents=True,exist_ok=True)
    r={'synthetic':True,'trained_model':False,'classes':summarize(['pavement']*4+['vegetation']*2+['water']*2,[.2,.3,.2,.3,.6,.8,.4,.6]),'limitation':'Synthetic labels and depth; not model accuracy. Relative depth is not distance in meters.'};(o/'report.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
if __name__=='__main__':main()
