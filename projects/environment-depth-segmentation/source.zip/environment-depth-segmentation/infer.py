"""Optional pretrained inference; install torch transformers pillow first."""
import argparse,json
from pathlib import Path
from PIL import Image
from transformers import pipeline
from demo import summarize
p=argparse.ArgumentParser();p.add_argument('image');p.add_argument('--output',default='output/inference');a=p.parse_args();o=Path(a.output);o.mkdir(parents=True,exist_ok=True)
image=Image.open(a.image).convert('RGB')
depth=pipeline('depth-estimation',model='depth-anything/Depth-Anything-V2-Small-hf',device=-1)(image)
segments=pipeline('image-segmentation',model='facebook/mask2former-swin-tiny-ade-semantic',device=-1)(image)
# Use the normalized display-depth map: no metric distance or calibrated depth claim.
depth_image=depth['depth'].resize(image.size);labels=['unassigned']*(image.width*image.height)
for segment in segments:
 mask=list(segment['mask'].resize(image.size,Image.Resampling.NEAREST).getdata())
 for idx,value in enumerate(mask):
  if value:labels[idx]=segment['label']
values=[v/255 for v in depth_image.getdata()]
report={'synthetic':False,'trained_model':False,'depth_representation':'normalized display depth, not meters','classes':summarize(labels,values)}
(o/'report.json').write_text(json.dumps(report,indent=2));depth_image.save(o/'depth.png')
