import unittest
from shapely.geometry import box
from analysis import coverage
class OverlayTests(unittest.TestCase):
 def test_overlap_not_double_counted(self):
  report,union=coverage(box(0,0,10,10),[box(0,0,6,10),box(4,0,10,10)])
  self.assertAlmostEqual(report['covered_area_m2'],100)
  self.assertAlmostEqual(report['overlap_excess_m2'],20)
 def test_clipping_and_empty_fragments(self):
  report,_=coverage(box(0,0,10,10),[box(-5,-5,5,5)])
  self.assertEqual(report['coverage_percent'],25)
  self.assertEqual(coverage(box(0,0,1,1),[])[0]['covered_area_m2'],0)
 def test_invalid_area(self):
  with self.assertRaises(ValueError):coverage(box(0,0,0,0),[])
