"""Environmental polygon overlay in local planar metric coordinates."""
from shapely.ops import unary_union

def coverage(area,fragments):
    if area.is_empty or not area.is_valid or area.area<=0:raise ValueError('Valid nonempty analysis area required')
    if any(not f.is_valid or f.is_empty for f in fragments):raise ValueError('Invalid fragment')
    clipped=[f.intersection(area) for f in fragments]
    union=unary_union(clipped)
    return {'covered_area_m2':union.area,'coverage_percent':100*union.area/area.area,'summed_intersections_m2':sum(f.area for f in clipped),'overlap_excess_m2':sum(f.area for f in clipped)-union.area},union
