# BiomaData — Sobreposição de áreas ambientais

Protótipo geoespacial independente inspirado no contexto do BiomaData. Não modifica nem integra automaticamente a aplicação original.

Interseção e união de polígonos para medir cobertura dentro de uma área, descontando sobreposições e recortando partes externas.

## Reproduzir
```bash
python -m pip install -r requirements.txt
python demo.py
python -m unittest discover -s tests -v
```

Exporta mapa SVG, relatório JSON e GeoJSON. `analysis.py` aceita polígonos Shapely para análise de dados autorizados. A demonstração utiliza apenas dados sintéticos em coordenadas planas locais em metros. GeoJSON local não deve ser sobreposto diretamente a mapas geográficos; dados em longitude/latitude precisam de reprojeção adequada.

## Técnicas e treinamento
Python, Shapely/GEOS e operações geométricas de interseção e união. Não há treinamento de IA.

## Limites
Area intersection and union only; no official conservation status, real deforestation detection or legal conclusion.

## Próximas etapas
Importar camadas autorizadas, validar CRS e geometrias e conectar a um fluxo de revisão do BiomaData. Adicionar métricas por categoria e avaliação temporal.
