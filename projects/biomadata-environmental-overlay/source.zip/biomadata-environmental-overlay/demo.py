import argparse,json
from pathlib import Path
from shapely.geometry import box,mapping,LineString
from shapely.ops import nearest_points
from analysis import coverage

def drawing(polygons,connections=()):
    paths=[]
    for p,color in polygons:
        shapes=list(p.geoms) if p.geom_type=='MultiPolygon' else [p]
        for g in shapes:
            if g.is_empty:continue
            rings=[g.exterior,*g.interiors]
            d=' '.join('M '+' L '.join(f'{x},{y}' for x,y in r.coords)+' Z' for r in rings)
            paths.append(f'<path d="{d}" fill="{color}" fill-rule="evenodd" stroke="#73c4d3" stroke-width=".6"/>')
    for line in connections:
        (x,y),(xx,yy)=line.coords;paths.append(f'<line x1="{x}" y1="{y}" x2="{xx}" y2="{yy}" stroke="#efb66b" stroke-width="1.5"/>')
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-5 -5 110 80"><rect x="-5" y="-5" width="110" height="80" fill="#0b1c33"/>'+''.join(paths)+'</svg>'

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',default='output');p.add_argument('--max-gap',type=float,default=18);a=p.parse_args();o=Path(a.output);o.mkdir(parents=True,exist_ok=True)
 area=box(0,0,100,70);fragments=[box(5,5,45,45),box(30,20,70,60),box(85,40,110,65)];metrics,union=coverage(area,fragments);polygons=[(area,'#294058'),(union,'#247f66')];lines=[];features=[{'type':'Feature','properties':{'kind':'analysis_area'},'geometry':mapping(area)},{'type':'Feature','properties':{'kind':'covered_union'},'geometry':mapping(union)}]
 report={'synthetic':True,'trained_model':False,'coordinate_system':'local planar meters; reproject geographic data before measuring','metrics':metrics,'limitation':'Area intersection and union only; no official conservation status, real deforestation detection or legal conclusion.'}
 (o/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8');(o/'map.svg').write_text(drawing(polygons,lines),encoding='utf-8')
 (o/'analysis.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features}),encoding='utf-8');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
